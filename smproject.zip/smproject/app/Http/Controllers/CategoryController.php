<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
  /*  public function __construct()
    {
        $this->middleware('auth');
    }*/



    public function index()
    {
        return Category::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required'
        ]);
        return Category::create($request->all());
    }

    public function show($id)
    {
        return Category::find($id);
    }

    public function update(Request $request, $id)
    {
        $category = Category::find($id);

        $request->validate([
            'name'=>'required'
        ]);
        $category = DB::table('categories')->where('id',$id)->update([
            'name'=>$request->get('name')
        ]);
        $q=DB::table('categories')->get();

        return response()->json($q) ;
    }

    public function destroy($id)
    {
        $category= Category::find($id);
        $category=Category::destroy($id);
          return $category;
    }
    public function search(Request $request)
    {
        $product = DB::table('products')->where('id',)->get();
        $search = $request->input('search');
        $test = DB::table('categories')->where('name','LIKE','%'.$search.'%')->get($product);
        return response()->json($test) ;
    }
}
