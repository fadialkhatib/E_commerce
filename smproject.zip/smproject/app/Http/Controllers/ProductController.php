<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\User;
use Carbon\Carbon;
use DateTime;
use Illuminate\Foundation\Auth\User as AuthUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Symfony\Component\Console\Input\Input;

class ProductController extends Controller
{
   /* public function __construct()
    {
        $this->middleware('auth');
    }*/




     //Display a listing of the resource.
    public function index()
    {
        $product = DB::table('products')->orderBy('created_at','DESC')->get()->paginate(4);
        return response()->json(['products'=>$product]);
    }


      //Create the form for creating a new resource.

    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'price'=>'required',
            'quantity'=>'required'
        ]);
       /* $img_url = $request->img_url;
        $newPhoto = time().$img_url->getClientOriginalName();
        $img_url=$newPhoto;*/

        $i=9;
        $i2=7;
        $q=DB::table('users')->where('id',$i)->get('id');
        $q1=DB::table('categories')->where('name','food')->get('id');
         $product= Product::create([    //query()
            'name'=>$request->name,
            'price'=>$request->price,
            'quantity'=>$request->quantity,
            'user_id'=>$i,
            // 'user_id'=>Auth::id(),
            'category_id'=>$i2,
            // 'category_id'=>Auth::id(),
            'description' => $request->description,
            'img_url'=>$request->img_url,
            'exp_date'=>$request->exp_date,
         ]);
         /*foreach($request->list_discounts as $discount)*/
         $product->discounts()->create([
             'date'=>$request->date,
             'discount_percentage'=>$request->discount_percentage
            ]);
            return response()->json($product) ;
            return response()->json(['message'=>'pruduct created succsesfully']);
            //            $product = Product::create($request->all());
//            return response()->json($product);



    }


     // Display the specified resource.

    public function show(Request $request ,$id)
    {
        $q1= DB::table('products')->where('id',$id)->value('name');
        $q=DB::table('products')->where('id',$id)->get();
        //return $q;


       /* $dt1 = Carbon::parse($date->date);
        $result = $dt1->lte(Carbon::now());
        if ($result == 'exp_date') {

        }*/
      /* $discounts=$product->discounts()->get();
        $maxDiscount =null;
        foreach($discounts as $discount){
            if(Carbon::parse($request->date) <= now()){
                $maxDiscount=$discount;
            }
        }
        if (!is_null($maxDiscount)) {
            $discount_value = ($product->price*$maxDiscount['discount_percentage'])/100;
            $product['current_price'] = $product->price - $discount_value;
        }
        return $product;$q;
*/
    }




    //  Update the specified resource in storage.

    public function update(Request $request, $id)
    {
        /*$request->validate([
            'name'=>"required",
            'price'=>"required",
            'quantity'=>"required"
        ]);*/

        $q1= DB::table('products')->where('id',$id)->value('name');
       // $product= DB::table('products')->where('id',$id)->where('user_id',$request->get('id'))->value('name');
        if ($q1==null) {
            return response()->json(['product not found']);
        }
       /* if($product==null)
        {
            return response()->json(['you do not have the permission']);
        }*/
        $product=DB::table('products')->where('id',$id)->update([
            'name'=>$request->get('name'),
            'price'=>$request->get('price'),
            'quantity'=>$request->get('quantity')
        ]);
        $q=DB::table('products')->where('id',$id)->get();
        return response()->json($q);
        return response()->json(['message'=>'pruduct updated succsesfully']);
        /*if ($request->has('img_url')) {
            $product->img_url = $request->img_url;
            $newPhoto = time().$img_url->getClientOriginalName();
            $img_url=$newPhoto;
        }
    }*/

    }

    //  Remove the specified resource from storage.


    public function destroy($id)
    {
        $q1= DB::table('products')->where('id',$id);
       // $product= DB::table('products')->where('id',$id)->where('user_id',$request->get('id'))->value('name');
        if ($q1==null) {
            return response()->json(['product not found']);
        }
        $q=DB::table('products')->where('id',$id)->delete();
        return response()->json(['message'=>'the product deleted succsesfully']);

       /* if($product==null)
        {
            return response()->json(['you do not have the permission']);
        }*/



    }
    public function search(Request $request){
        /*$product= DB::table('products')->where('name',$name)->get();
        $q= DB::table('products')->where('name',$name)->get();

        return response()->json($q);*/

        $search = $request->input('search');
        $test = DB::table('products')->where('name','LIKE','%'.$search.'%')->orWhere('exp_date','LIKE','%'.$search.'%')->get();
        return response()->json($test) ;
    }
}
