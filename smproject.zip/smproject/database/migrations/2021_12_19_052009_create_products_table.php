<?php

use Facade\Ignition\Tabs\Tab;
use Faker\Provider\ar_EG\Text;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
           $table->increments('id');
           $table->string('name');
           $table->double('price');
           $table->text('description');
           $table->date('exp_date');
           $table->text('img_url');
           $table->integer('quantity');
           $table->timestamps();

           $table->unsignedInteger('user_id');
           $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
           $table->unsignedInteger('category_id');
           $table->foreign('category_id')->references('id')->on('categories')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
