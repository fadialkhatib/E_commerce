<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});*/

//Public Routes
Route::prefix('prod')->group(function(){
    Route::get('/','ProductController@index');
    Route::get('/{id}','ProductController@show');
    Route::post('/search','ProductController@search');
});

Route::prefix('cat')->group(function(){
    Route::get('/','CategoryController@index');
    Route::get('/{id}','CategoryController@show');
    Route::get('/{name}','CategoryController@search');
    Route::post('/','CategoryController@store');
    Route::put('/{id}','CategoryController@update');
    Route::delete('/{id}','CategoryController@destroy');
    Route::get('/{name}','CategoryController@search');
});
Route::post('/register',[AuthController::class,'register']);
Route::post('/login',[AuthController::class,'login']);


//Private Routes
Route::middleware(['auth:sanctum'])->group(function(){

    Route::post('/prod','ProductController@store');
    Route::put('/prod/{id}','ProductController@update');
    Route::delete('/prod/{id}','ProductController@destroy');
    Route::post('/logout',[AuthController::class,'logout']);
    });


    //Multie Languages
   /* Route::group(
        [
            'prefix' => LaravelLocalization::setLocale(),
            'middleware' => [ 'localeSessionRedirect', 'localizationRedirect', 'localeViewPath' ]
        ],function(){
            Route::post('/register',[AuthController::class,'register']);
            Route::post('/login',[AuthController::class,'login']);
            Route::post('/prod','ProductController@store');
            Route::put('/prod/{id}','ProductController@update');
            Route::delete('/prod/{id}','ProductController@destroy');
            Route::post('/logout',[AuthController::class,'logout']);
        });*/
